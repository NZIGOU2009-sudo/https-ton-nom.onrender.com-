const express = require("express");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const OpenAI = require("openai");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const AI_MODEL = process.env.AI_MODEL || "gpt-4o-mini";

if (!ADMIN_PASSWORD || !SESSION_SECRET || !OPENAI_API_KEY) {
  console.error("Configuration manquante : ADMIN_PASSWORD, SESSION_SECRET et OPENAI_API_KEY sont requis.");
  process.exit(1);
}
if (ADMIN_PASSWORD.length < 14) {
  console.error("ADMIN_PASSWORD doit faire au moins 14 caractères.");
  process.exit(1);
}
if (SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET doit faire au moins 32 caractères.");
  process.exit(1);
}

const ai = new OpenAI({ apiKey: OPENAI_API_KEY });
app.disable("x-powered-by");
app.use(express.json({ limit: "10kb" }));
app.use(session({
  name: "echo_admin",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));
app.use(express.static(path.join(__dirname, "public"), { index: "index.html" }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const sendLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const messages = [];
let mode = "auto"; // auto, manual, hybrid
let nextId = 1;
const MAX_MESSAGES = 300;

function addMessage(role, text, extra = {}) {
  const item = { id: nextId++, role, text: String(text).slice(0, 3000), time: new Date().toISOString(), ...extra };
  messages.push(item);
  if (messages.length > MAX_MESSAGES) messages.splice(0, messages.length - MAX_MESSAGES);
  return item;
}
function adminOnly(req, res, next) {
  if (!req.session || !req.session.isAdmin) return res.status(401).json({ error: "Connexion administrateur requise." });
  next();
}
function cleanText(value) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, 1500);
}

app.get("/api/status", (_req, res) => res.json({ mode, messages: messages.length }));
app.get("/api/messages", (_req, res) => res.json({ messages }));
app.post("/api/messages", sendLimiter, async (req, res) => {
  const text = cleanText(req.body?.text);
  if (!text) return res.status(400).json({ error: "Écris un message avant d’envoyer." });
  addMessage("user", text);
  if (mode === "manual") return res.json({ ok: true, waitingForAdmin: true });

  if (mode === "hybrid") {
    try {
      const suggestion = await generateReply(text);
      addMessage("suggestion", suggestion);
      return res.json({ ok: true, suggestionPending: true });
    } catch (e) {
      console.error("Erreur IA:", e.message);
      return res.status(502).json({ ok: true, aiError: "La génération IA a échoué. L’administrateur peut répondre manuellement." });
    }
  }
  try {
    const answer = await generateReply(text);
    addMessage("assistant", answer);
    return res.json({ ok: true });
  } catch (e) {
    console.error("Erreur IA:", e.message);
    addMessage("system", "L’IA est momentanément indisponible. Réessaie dans un instant.");
    return res.status(502).json({ error: "La génération IA a échoué. Vérifie la clé API et les crédits du fournisseur." });
  }
});

async function generateReply(userText) {
  const recent = messages.filter(m => ["user", "assistant", "admin"].includes(m.role)).slice(-16);
  const history = recent.map(m => ({
    role: m.role === "user" ? "user" : "assistant",
    content: m.text
  }));
  const completion = await ai.chat.completions.create({
    model: AI_MODEL,
    temperature: 0.85,
    max_tokens: 220,
    messages: [
      { role: "system", content: "Tu es Echo, un chatbot de conversation amical, naturel et légèrement drôle. Réponds en français, brièvement, comme dans une conversation de messagerie. Ne prétends pas être une personne réelle. Si l’utilisateur demande, indique clairement que tu es une IA. N’invente pas de faits personnels ni de rendez-vous confirmés." },
      ...history.slice(0, -1),
      { role: "user", content: userText }
    ]
  });
  return (completion.choices[0]?.message?.content || "Je n’ai pas trouvé de réponse, réessaie 😅").trim();
}

app.post("/api/admin/login", loginLimiter, (req, res) => {
  const password = typeof req.body?.password === "string" ? req.body.password : "";
  const a = Buffer.from(password);
  const b = Buffer.from(ADMIN_PASSWORD);
  const valid = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!valid) return res.status(401).json({ error: "Mot de passe incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Impossible d’ouvrir la session." });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", adminOnly, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/state", adminOnly, (_req, res) => res.json({ mode, messages }));
app.post("/api/admin/mode", adminOnly, (req, res) => {
  const requested = req.body?.mode;
  if (!["auto", "manual", "hybrid"].includes(requested)) return res.status(400).json({ error: "Mode invalide." });
  mode = requested;
  res.json({ ok: true, mode });
});
app.post("/api/admin/reply", adminOnly, (req, res) => {
  const text = cleanText(req.body?.text);
  if (!text) return res.status(400).json({ error: "La réponse ne peut pas être vide." });
  res.json({ ok: true, message: addMessage("admin", text) });
});
app.post("/api/admin/approve/:id", adminOnly, (req, res) => {
  const id = Number(req.params.id);
  const suggestion = messages.find(m => m.id === id && m.role === "suggestion");
  if (!suggestion) return res.status(404).json({ error: "Proposition introuvable." });
  suggestion.role = "assistant";
  suggestion.approved = true;
  res.json({ ok: true });
});
app.post("/api/admin/clear", adminOnly, (_req, res) => {
  messages.splice(0, messages.length);
  res.json({ ok: true });
});

app.get("/admin", (_req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("/health", (_req, res) => res.type("text").send("ok"));
app.listen(PORT, () => console.log(`Echo écoute sur le port ${PORT}`));
