# Echo — chat IA avec panneau administrateur

Projet Node.js/Express prêt à être déployé sur Render. `render.yaml` décrit le service et configure les réglages de base. Le site public est `/` et le panneau administrateur est `/admin`.

## Important avant publication

- Le site informe les visiteurs qu'ils discutent avec une IA et qu'un administrateur peut intervenir.
- Ne mets jamais une clé API ni un mot de passe dans GitHub ou dans le code du navigateur.
- La clé API OpenAI peut entraîner des frais distincts d'un abonnement ChatGPT. Configure des limites de dépenses sur le compte API.
- Cette version de départ stocke messages et sessions en mémoire : un redémarrage efface l'historique et déconnecte l'administrateur. Pour un usage durable, ajoute une base de données et un stockage de sessions persistant.
- Il s'agit d'un salon partagé sans comptes visiteurs. Ne l'utilise pas pour des informations sensibles.

## Déploiement Render

1. Ajoute le contenu de ce dossier à un dépôt GitHub. Conserve `render.yaml` à la racine du dépôt (au même niveau que `package.json` et `server.js`).
2. Dans Render, choisis **New + → Blueprint** et connecte le dépôt. Si Blueprint n'est pas proposé, crée un **Web Service** avec `npm install` comme Build Command et `npm start` comme Start Command.
3. Lorsqu'on te le demande, renseigne `OPENAI_API_KEY` et `ADMIN_PASSWORD`. Render génère `SESSION_SECRET` automatiquement via `render.yaml`.
4. Lance le déploiement et attends le statut **Live**.
5. L'adresse du chat est l'URL Render. L'adresse d'administration est la même suivie de `/admin`.
6. Teste le chat et la connexion administrateur avant de partager l'adresse.

## Variables d'environnement

- `OPENAI_API_KEY` : clé API OpenAI (secret)
- `ADMIN_PASSWORD` : mot de passe administrateur unique d'au moins 14 caractères
- `SESSION_SECRET` : secret de session (32 caractères minimum ; Render le génère via le Blueprint)
- `NODE_ENV=production`
- `AI_MODEL=gpt-4o-mini` (modifiable selon les modèles disponibles pour le compte)

## Lancer en local

Prérequis : Node.js 20 ou plus récent.

```sh
npm install
cp .env.example .env
# Renseigner les variables dans .env, sans partager ce fichier
npm start
```

Ouvre `http://localhost:3000` pour le chat et `http://localhost:3000/admin` pour l'administration.
